class FooterComponent extends HTMLElement {
  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: 'open' });

    // 1) Inject ALL of the CSS + HTML inside one template literal
    this.shadow.innerHTML = `
      <style>
        .site-footer {
          background: rgba(255, 255, 255, 0.1);
          backdrop-filter: blur(6px);
          color: #eee;
          font-size: 0.9rem;
          text-align: center;
          padding: 1rem 2rem;
          border-top: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
          opacity: 0;
          transform: translateY(20px);
          transition: opacity 0.6s ease-out, transform 0.6s ease-out;
          position: relative;
        }
        .site-footer.visible {
		  border-radius: 1rem;
          opacity: 1;
          transform: translateY(0);
        }

        /* Dark‐mode overrides */
        @media (prefers-color-scheme: dark) {
          .site-footer {
            background: rgba(0, 0, 0, 0.3);
            color: #ccc;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
          }
        }

        /* Donut icon float animation */
        .donut-icon {
          position: absolute;
          top: -20px;
          right: 20px;
          width: 40px;
          height: 40px;
          cursor: pointer;
          animation: float 3s ease-in-out infinite;
          transition: transform 0.3s ease;
        }
        .donut-icon:hover {
          transform: translateY(-5px) scale(1.05);
        }
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
      </style>

      <footer class="site-footer">
        Crafted for the DEV July Frontend Challenge sponsored by Axero • prompt: "Holistic Webdev" • intranet homepage for a fictional company using CSS, HTML, and JavaScript
        <img
          src="assets/images/donut_0001.png"
          alt="Donut icon"
          class="donut-icon"
          role="button"
          tabindex="0"
          aria-label="Click the donut for a surprise"
        />
      </footer>
    `;
  }

  connectedCallback() {
    // 2) Now that the markup is in the shadow, we can query it
    const footer = this.shadow.querySelector('.site-footer');
    const donut  = this.shadow.querySelector('.donut-icon');

    // Fade it up
    requestAnimationFrame(() => {
      footer.classList.add('visible');
    });

    // Click interaction
    donut.addEventListener('click', () => {
      alert("🍩 You found the donut! Office treats unlocked.");
    });
  }
}

customElements.define('footer-component', FooterComponent);
