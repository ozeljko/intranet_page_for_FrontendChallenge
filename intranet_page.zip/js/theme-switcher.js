(() => {
  const root       = document.documentElement;
  const THEME_KEY  = 'user-theme';
  const SELECT_ID  = 'theme-select';
  const THEME_PATH = 'js/data';

  async function applyTheme(theme) {
    console.log('applyTheme start:', theme);
    const res  = await fetch(`${THEME_PATH}/${theme}-theme.json`);
    console.log(res.ok ? '✅ JSON fetched' : '❌ fetch failed', res.status);
    const vars = await res.json();
    console.log('vars from JSON:', vars);

    Object.entries(vars).forEach(([key, val]) => {
      // convert camelCase to kebab-case
      const prop = key.replace(/([A-Z])/g, '-$1').toLowerCase();
      console.log(`  setting --${prop} = ${val}`);
      root.style.setProperty(`--${prop}`, val);
    });

    root.setAttribute('data-theme', theme);
    localStorage.setItem(THEME_KEY, theme);
  }

  function initThemeSwitcher() {
    const select      = document.getElementById(SELECT_ID);
    const storedTheme = localStorage.getItem(THEME_KEY);
    const prefersDark = matchMedia('(prefers-color-scheme: dark)').matches;
    // pick saved theme if present, otherwise follow OS preference
    const themeToApply = storedTheme || (prefersDark ? 'dark' : 'default');

    if (!select) {
      console.warn('No theme-select found—skipping switcher init');
      applyTheme(themeToApply);
      return;
    }

    select.value = themeToApply;
    select.addEventListener('change', () => applyTheme(select.value));
    applyTheme(themeToApply);
  }

  // expose so you can call it after header injection
  window.initThemeSwitcher = initThemeSwitcher;
})();
