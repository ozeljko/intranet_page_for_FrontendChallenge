document.getElementById('search-button').addEventListener('click', () => {
  const query = document.getElementById('employee-query').value.toLowerCase();
  console.log(`Searching employees for: ${query}`);

  // result just for fun and preview
  document.getElementById('search-results').innerHTML = `
    <div class="employee-card">
      <p><strong>Name:</strong> Glazey McSprinkle</p>
      <p><strong>Team:</strong> R&D</p>
      <p><strong>Job Title:</strong> Chief Flavor Officer</p>
    </div>
  `;
});
