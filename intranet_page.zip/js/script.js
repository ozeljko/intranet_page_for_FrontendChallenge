document.addEventListener('DOMContentLoaded', () => {
  // 1. Smooth scroll nav links
  const navLinks = document.querySelectorAll('.nav-links a');
  const header = document.querySelector('.header');
  const headerHeight = header ? header.offsetHeight : 0;

  navLinks.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const targetId = link.getAttribute('href').slice(1);
      const targetEl = document.getElementById(targetId);
      if (!targetEl) return;
      const topPos = targetEl.getBoundingClientRect().top + window.pageYOffset - headerHeight;
      window.scrollTo({ top: topPos, behavior: 'smooth' });
    });
  });

  // 2. Highlight active link on scroll
  const sections = Array.from(document.querySelectorAll('main section[id]'));
  window.addEventListener('scroll', () => {
    const scrollPos = window.scrollY + headerHeight + 5;
    let current = sections[0];
    for (let sec of sections) {
      if (sec.offsetTop <= scrollPos) current = sec;
    }
    navLinks.forEach(link => {
      link.classList.toggle(
        'active',
        link.getAttribute('href') === `#${current.id}`
      );
    });
  });

  // 3. Countdown timer for Upcoming Event
  const upcoming = document.getElementById('events');
  if (upcoming) {
    // Ensure your <section id="events"> has a `data-event-date="YYYY-MM-DDTHH:MM:SS"` attribute
    const dateAttr = upcoming.getAttribute('data-event-date');
    if (dateAttr) {
      const countdownEl = document.createElement('div');
      countdownEl.className = 'countdown';
      upcoming.appendChild(countdownEl);

      const eventDate = new Date(dateAttr);
      const update = () => {
        const now = new Date();
        const diff = eventDate - now;
        if (diff <= 0) {
          countdownEl.textContent = 'The event is happening now!';
          clearInterval(timer);
          return;
        }
        const days = Math.floor(diff / 86400000);
        const hours = Math.floor((diff % 86400000) / 3600000);
        const mins = Math.floor((diff % 3600000) / 60000);
        const secs = Math.floor((diff % 60000) / 1000);
        countdownEl.textContent =
          `Starts in ${days}d ${hours}h ${mins}m ${secs}s`;
      };

      update();
      const timer = setInterval(update, 1000);
    }
  }
});
